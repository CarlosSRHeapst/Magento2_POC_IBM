/**
 * Copyright Adobe.
 * See COPYING.txt for license details.
 */

define([
    'jquery'
], function () {
    'use strict';

});

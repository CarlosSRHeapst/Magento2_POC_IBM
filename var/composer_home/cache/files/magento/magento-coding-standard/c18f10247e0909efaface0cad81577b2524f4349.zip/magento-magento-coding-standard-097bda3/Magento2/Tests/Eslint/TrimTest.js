define([
    'jquery',
], function ($) {
    $(function () {
        'use strict';

        $.trim('    hello, how are you?    ');
    });
});

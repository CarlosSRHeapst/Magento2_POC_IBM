define([
    'jquery',
], function ($) {
    $(function () {
        'use strict';

        $.parseJSON('');
        $.type({});
        $.isArray({});
        $.isFunction({});
    });
});

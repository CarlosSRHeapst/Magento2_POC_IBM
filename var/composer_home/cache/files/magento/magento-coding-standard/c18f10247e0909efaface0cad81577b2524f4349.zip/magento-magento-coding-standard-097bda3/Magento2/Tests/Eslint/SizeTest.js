define([
    'jquery',
], function ($) {
    $(function () {
        'use strict';

        $('div').size();
    });
});

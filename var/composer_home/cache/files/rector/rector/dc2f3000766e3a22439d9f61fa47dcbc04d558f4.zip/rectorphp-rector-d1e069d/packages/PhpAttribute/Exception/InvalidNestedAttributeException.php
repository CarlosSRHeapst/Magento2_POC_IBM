<?php

declare (strict_types=1);
namespace Rector\PhpAttribute\Exception;

use Exception;
final class InvalidNestedAttributeException extends Exception
{
}
